<?php
$goods = [
            [
                "id" => 1,
                "image" => "images/main/goods/pinephone-pro.png",
                "name" => "PinePhone Pro",
                "description" => "Meet the PinePhone Pro, our flagship smartphone and the best way to experience mainline Linux on a mobile device",
                "price" => "$399"
            ]
            ,
            [
                "id" => 2,
                "image" => "images/main/goods/kde-slimbook.png",
                "name" => "KDE Slimbook",
                "description" => "The Linux ultrabook with a Ryzen 5700U processor and KDE's full-featured Plasma desktop running on KDE Neon and with access to hundreds of Open Source programs and utilities",
                "price" => "$1050"
            ]
            ,
            [
                "id" => 3,
                "image" => "images/main/goods/banana-pi.png",
                "name" => "Banana Pi",
                "description" => "The Banana Pi hardware runs Android, Debian Linux, Ubuntu Linux, OpenSuse linux and images that run on the Raspberry Pi and Cubieboard. Banana PI has a Gigabit Ethernet port and a SATA socket. It can run with Android 4.2.2 smoothly. It can easily run games as it supports 1080P high definition video output.",
                "price" => "$52"
            ],
            [
                "id" => 1,
                "image" => "images/main/goods/pinephone-pro.png",
                "name" => "PinePhone Pro",
                "description" => "Meet the PinePhone Pro, our flagship smartphone and the best way to experience mainline Linux on a mobile device",
                "price" => "$399"
            ]
            ,
            [
                "id" => 2,
                "image" => "images/main/goods/kde-slimbook.png",
                "name" => "KDE Slimbook",
                "description" => "The Linux ultrabook with a Ryzen 5700U processor and KDE's full-featured Plasma desktop running on KDE Neon and with access to hundreds of Open Source programs and utilities",
                "price" => "$1050"
            ]
            ,
            [
                "id" => 3,
                "image" => "images/main/goods/banana-pi.png",
                "name" => "Banana Pi",
                "description" => "The Banana Pi hardware runs Android, Debian Linux, Ubuntu Linux, OpenSuse linux and images that run on the Raspberry Pi and Cubieboard. Banana PI has a Gigabit Ethernet port and a SATA socket. It can run with Android 4.2.2 smoothly. It can easily run games as it supports 1080P high definition video output.",
                "price" => "$52"
            ]  
        ];
?>