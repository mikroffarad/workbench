<section class="promo-text">
    <div class="container">
        <div class="promo-text__inner"> 
            <p class="promo-text__header promo-text__header--red-text">Avoid <span class="promo-text__accent">proprietary</span> products</p>
            <p class="promo-text__header promo-text__header--green-text">Use <span class="promo-text__accent">open-source</span> solutions</p>
        </div>
    </div>
</section>
<section class="main-text">
    <div class="container">
        <div class="main-text__inner">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sunt temporibus ipsum facere iure culpa nihil saepe omnis, aperiam facilis ut adipisci delectus et, vero impedit optio cum quaerat. Blanditiis sed quisquam praesentium expedita asperiores dolor nostrum maxime ducimus deleniti magni distinctio quia amet minus error, provident est veritatis ratione, fugit corrupti. Rem architecto iste, sed recusandae pariatur dicta optio quam dolorem alias animi molestias est illum beatae tempore debitis eaque ullam odit minima id atque iure reprehenderit. Magnam dolorem autem, iste fugit, eaque vero labore, iure illum maiores ullam natus. Quidem deserunt porro quas voluptate enim laborum nostrum dicta facere?
        </div>
    </div>          
</section>